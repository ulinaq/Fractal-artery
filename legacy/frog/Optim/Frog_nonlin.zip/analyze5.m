prm = Frog_parameter();
prm.type = 1;
[Trans,Grid] = FO_Darcy3(prm);    % Load the image domain and create darcy domain. Then compute transmibility
% ResT = zeros(4,20); 
% QT = zeros(4,20); 
% xSave = zeros(765,4,20);
% jk = 1;
for jk = 1:4
for jn = 11:20
% jn=12;
[node,segment,vnode,vsegment] = segOne(prm,Grid,0,0);
if jn==20
    switch jk
        case 1
            segment.rad(74)=segment.rad(74)/100;   % segment that is damaged has much smaller radii
        case 2
            segment.rad(85)=segment.rad(85)/100;   % segment that is damaged has much smaller radii
        case 3
            vsegment.rad(223)=vsegment.rad(223)/100;
        case 4
            vsegment.rad(173)=vsegment.rad(173)/100;
    end
else
    switch jk
        case 1
            segment.rad(74)=(20-jn)*segment.rad(74)/20;   % segment that is damaged has much smaller radii
        case 2
            segment.rad(85)=(20-jn)*segment.rad(85)/20;   % segment that is damaged has much smaller radii
        case 3
            vsegment.rad(223)=(20-jn)*vsegment.rad(223)/20;
        case 4
            vsegment.rad(173)=(20-jn)*vsegment.rad(173)/20;
    end
end
[Xr,Grid] = FO_Capillary2(node,vnode,Grid);
Xr.Pext = Xr.C([segment.ext; vsegment.ext],:);
% x = Frog_LinEq(prm,node,segment,vnode,vsegment,Xr.P);
if jn ==1
    guess = MObase.x;
else
    guess = xSave(:,jk,jn-1);
end
% guess =xSave(:,jk,jn);
x = Frog_nonlinEq3(node,prm,segment,vnode,vsegment,Xr,1,guess);
Co = node.n + vnode.n;  Cv = Co + segment.n;
in = x([Co+segment.num(segment.isterminal)]);
out = x([Cv+vsegment.num(vsegment.isterminal)]);
q = [in/sum(in)*sum(out);-1*out];
P = Xr.C*q+x(end);
xSave(:,jk,jn) = x;
QT(jk,jn) = sum(x([Co+segment.num(segment.isroot)])); 
ResT(jk,jn) = (prm.Pin-prm.Pout)/QT(jk,jn);
(prm.Pin-prm.Pout)/QT(jk,jn)
name = ['Occl2-',num2str(jk),'_on_',num2str(jn*5),'%'];
yr = PlotPressure(prm,segment,vsegment,node,x,name);
end
end

% for i=1:19
%     temp(:,i)=ResT(:,20-i);
% % end
PP = [ones(1,4)*2.1410;ResT(:,1:20)'];
Fr = [0:5:95,99];
figure;plot(Fr,PP,'LineWidth',2)
title('Total Resistance'); 
xlabel('Vessel occlusion [%]')
ylabel('R [kg.mm^{-4}s^{-1}]')
legend('artery-1','artery-2','vein-1','vein-2')