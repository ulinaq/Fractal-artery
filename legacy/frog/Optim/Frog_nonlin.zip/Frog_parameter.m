function prm = Frog_parameter()
%% Artery Parameters
% blood and flow parameters (all unit in mmgs)
prm.Rho = 1e-6;       % kg/mm3
prm.mu = 3e-6;        % kg/mm.s
prm.perm = 3e-8;      % mm2
prm.Pin = 3.99967105;          % kg/mm.s2
prm.Pout = 1;         % kPa
prm.pixel = 6e-2;   % milimeter
prm.alpha = 5e-4;    % Perdusion parameter
prm.beta = 2;         % relative permeability of vein compartment to artery compartment
prm.gamma = 5e-2;     % kg/mm4.s (resistance parameter around terminal nodes)
prm.E = 5e2;        % kPa
prm.Poison = 0.5;     % Poisson's ratio
prm.ha = 0.22;           % arterial wall thickness coeff.
prm.hv = 0.1;          % vein wall thickness coeff.
prm.Por = 0.1;
prm.type = 3;
prm.mmHg = 7.50061683;


% Geometry parameters
prm.Ro = 2;      % Initial radius 
prm.LtoR = 10;    % Ratio between length and radius
prm.Mexp = 2.8;    % Bifurcation exponent
prm.Rmin = 0.85*prm.Ro;  % Minimum radius
prm.N = 2;              % number of bifurcation
prm.a_init = [35,0];       % [x,y] initial point coordinate(root terminal)
prm.a_theta = pi/2;        % initial theta respect to x-axis
gamma = 1.4;               % Radius ratio between both childs vessel (degree of symmetry)
[prm.phi,prm.ratio]=phiratio(prm, gamma);

%% Vein Parameter
% Geometry parameters
prm.Rvo = 1.2*prm.Ro;       % Initial radius 
prm.Rvmin = 1.2*prm.Rmin;   % Minimum radius
prm.v_init=[30,0];       % [x,y] initial point coordinate(root terminal)
prm.v_theta = pi/2;         % initial theta respect to x-axis
gamma = 1.2;                  % Radius ratio between both childs vessel (degree of symmetry)
[prm.vphi,prm.vratio]=phiratio(prm, gamma);
for i = 1:5
    gamma = rand(1);
    [phi,ratio] = phiratio(prm, gamma);
    prm.phi = [prm.phi; phi];
    prm.ratio = [prm.ratio; ratio];
end
for i = 1:5
    gamma = rand(1);
    [phi,ratio] = phiratio(prm, gamma);
    prm.vphi = [prm.vphi; phi];
    prm.vratio = [prm.vratio; ratio];
end
% Ratio between parent and 2 childs vessel
    function [phi,ratio] = phiratio(prm, gamma)
        delta = (1+gamma^(prm.Mexp/2))^(-1/prm.Mexp); 
        beta = delta*sqrt(gamma);
        phi(1) = acos((1+delta^4-beta^4)/(2*delta^2));    % angle between first and parent
        phi(2) = acos((1-delta^4+beta^4)/(2*beta^2));     % angle between second and parent
        ratio = [delta, beta];   % Radius ratio between 2 childs to the parent vessel
    end
end