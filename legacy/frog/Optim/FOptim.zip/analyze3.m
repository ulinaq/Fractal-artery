tic
prm = Frog_parameter();
[Trans,Grid] = FO_Darcy3(prm);    % Load the image domain and create darcy domain. Then compute transmibility
[node,segment,vnode,vsegment] = seggg(prm,Grid,0,0);
[Xr,Grid] = FO_Capillary2(node,vnode,Grid);
Xr.Pext = Xr.C([segment.ext; vsegment.ext],:);
% x = Frog_LinEq(prm,node,segment,vnode,vsegment,Xr.P);
for i = 1:8
    name = ['_type_',num2str(i)];
    switch i
    case 1
        x = Frog_LinEq(prm,node,segment,vnode,vsegment,Xr.P);
    case 2
        x = Frog_nonlinEqE(node,prm,segment,vnode,vsegment,Xr);
    case 3
        x = Frog_nonlinEqJ(node,prm,segment,vnode,vsegment,Xr);
    case 4
        prm.type=3;
        x = Frog_nonlinEq3(node,prm,segment,vnode,vsegment,Xr);
    case 5    
        [node,segment,vnode,vsegment] = seggg(prm,Grid,0,0);
        segment.rad(74)=segment.rad(74)/50;   % segment that is damaged has much smaller radii
        prm.type=3;
        x = Frog_nonlinEq3(node,prm,segment,vnode,vsegment,Xr);
    case 6
        [node,segment,vnode,vsegment] = seggg(prm,Grid,0,0);
        segment.rad(85)=segment.rad(85)/50;   % segment that is damaged has much smaller radii
        prm.type=3;
        x = Frog_nonlinEq3(node,prm,segment,vnode,vsegment,Xr);
    case 7
        [node,segment,vnode,vsegment] = seggg(prm,Grid,0,0);
        vsegment.rad(223)=vsegment.rad(223)/50;
        prm.type=3;
        x = Frog_nonlinEqE(node,prm,segment,vnode,vsegment,Xr);
    otherwise
        [node,segment,vnode,vsegment] = seggg(prm,Grid,0,0);
        vsegment.rad(173)=vsegment.rad(173)/50;   % segment that is damaged has much smaller radii
        prm.type=3;
        x = Frog_nonlinEqE(node,prm,segment,vnode,vsegment,Xr);
    end

    Var(i) = Itungan(x,name,prm,Trans,Grid,node,segment,vnode,vsegment,Xr);
    dat(i,:) = [Var(i).RAtree,Var(i).RAcap,Var(i).RVcap,Var(i).RVtree];
    RAT(i) = 100*Var(i).RAtree/Var(i).RTot;
    RAC(i) = 100*Var(i).RAcap/Var(i).RTot;
    RVT(i) = 100*Var(i).RVtree/Var(i).RTot;
    RVC(i) = 100*Var(i).RVcap/Var(i).RTot;

end
toc

xy = ['Baseline' 'Elasticity' 'Junction' 'Junction-Elasticity'];
xy = 1:8;
H = figure('Position',[300,200,800,500]);
bar(xy,dat,'stacked')
xlabel('model')
legend('R_{aN}','R_{aC}','R_{vN}','R_{vC}')
ylabel('R [kg.mm^{-4}s^{-1}]')
hold on
set(gcf, 'Color', 'w'); 
export_fig('Plotbar','-r300'); 

function [Var] = Itungan(x,name,prm,Trans,Grid,node,segment,vnode,vsegment,Xr)
Var.name=name;
[Pa,Pv,V] = Detail(x,name,Grid,prm,Trans,node,segment,vnode,vsegment,Xr);
Var.range= [min(Pa(Grid.B)) max(Pa(Grid.B))];
Var.x=x;
Co = node.n + vnode.n; Cv = Co+segment.n;
Var.Q = sum(x([Co+segment.num(segment.isroot)]));
Var.RTot = (prm.Pin-prm.Pout)/Var.Q;
dPa = mean(x(node.isterminal));
dPv = mean(x(node.n+vnode.num(vnode.isterminal)));
dPC = 0.5*(max(Pv(Grid.B))+min(Pa(Grid.B)));
Var.RAtree = (prm.Pin-dPa)/Var.Q;
Var.RAcap = (dPa-dPC)/Var.Q;
Var.RVcap = (dPC-dPv)/Var.Q;
Var.RVtree = (dPv-prm.Pout)/Var.Q;
end

function [Pa,Pv,V] = Detail(x,name,Grid,prm,Trans,node,segment,vnode,vsegment,Xr)
Co = node.n + vnode.n;  Cv = Co + segment.n;
in = x([Co+segment.num(segment.isterminal)]);
out = x([Cv+vsegment.num(vsegment.isterminal)]);
q = [in/sum(in)*sum(out);-1*out]; 
P = Xr.C*q+x(end);
Pa = reshape(P(1:Grid.N),Grid.Nx,Grid.Ny);
Pv = reshape(P(Grid.N+1:2*Grid.N),Grid.Nx,Grid.Ny);
GV=graph(vsegment.init,vsegment.end,abs(x(Cv+vsegment.num)));
GA=graph(segment.init,segment.end,abs(x(Co+segment.num)));
GV.Edges.width=10*sqrt(abs(GV.Edges.Weight)/sum(out));
GA.Edges.width=10*sqrt(abs(GA.Edges.Weight)/sum(in));
V = Flux(prm,Pa,Pv,Grid,Trans,q,node,vnode,segment,x);
analyze(prm,P,V,Grid,GA,GV,node,vnode,name);
end
