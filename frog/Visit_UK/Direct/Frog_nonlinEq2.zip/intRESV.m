lim = size(coSave,2)-1;
coS = coSave(:,1:lim);
Co = node.n + vnode.n;  Cv = Co + segment.n;    Cq = Cv+vsegment.n; 
Fri = x(Co+segment.num(segment.end==117));
Fro = x(Cv+vsegment.num(vsegment.end==244));
% inp = segment.distrind{segment.num(segment.end==117)};
% onp = vsegment.distrind{vsegment.num(vsegment.end==244)};
inp = segment.distrind{segment.num(segment.end==117)};
onp = vsegment.distrind{vsegment.num(vsegment.end==244)}{end};
Roi = logical(F1);
roi = full(mean(coS(Roi,1:lim)))';
% % Roi = logical(freehand3);
% % roi2 = full(mean(coS(Roi,1:lim)))';
% % Roi = logical(freehand4);
% % roi3 = full(mean(coS(Roi,1:lim)))';
% % figure;plot(Time,roi,Time,roi2,Time,roi3)
% roi = roi - min(roi(:));
c = mean(coS(inp{1},:))'; %sub2ind([Grid.Nx Grid.Ny],106,56)
c1 = mean(coS(inp{end},:))'; %sub2ind([Grid.Nx Grid.Ny],106,56)
% c = c - min(c);
cv = mean(coS(onp,:))';
% cv = cv - min(cv);
% 
t = Time(1:lim);
Cai = INT_TRAP(t,c);
Cvo = INT_TRAP(t,cv);
Cr = INT_TRAP(t,roi);
N = roi(1:lim)*(sum(Roi(:))-13)*Grid.volume;
N2 = INT_TRAP(t,c*Fri-cv*Fro);
Cr = INT_TRAP(t,N);
Cr2 = INT_TRAP(t,N2);
[Cr(end) Cr2(end)]
(Cr(end)-Cr2(end))/Cr2(end)*100
figure; plot(t,N,t,N2,'LineWidth',2);
legend('N_{ROI}(t)','N_{inside}(t)')
xlabel('Time[s]')
ylabel('Number of moles[mmol]')
% 
N3 = INT_TRAP(t,Cai*Fri-Cvo*Fro);
F = N3./(Cai-Cvo);
figure; plot(t,Cai,t,Cvo,'LineWidth',2);
legend('Ca(t)dt','Cv(t)dt')
xlabel('Time[s]')
ylabel('[mmol ml^{-1} s]')
% figure; plot(t,N3,'LineWidth',2);
% legend('N_{ROI}(t)')
% xlabel('Time[s]')
% ylabel('Mol[mmol]')

% % %% Freehand 2
% % Co = node.n + vnode.n;  Cv = Co + segment.n;    Cq = Cv+vsegment.n;
% Roi = logical(freehand2);
% roi = full(mean(coS(Roi,1:lim)))';
% roi = roi - min(roi(:));
% Fri = [x(Co+segment.num(segment.end==5)),x(Co+segment.num(segment.end==6))];
% Fro = [x(Cv+vsegment.num(vsegment.end==3))];
% inp = segment.distrind{segment.num(segment.end==5)};
% onp = vsegment.distrind{vsegment.num(vsegment.end==3)};
% 
% % Fri = [x(Co+segment.num(segment.end==103)),x(Co+segment.num(segment.end==110))];
% % Fro = [x(Cv+vsegment.num(vsegment.end==186)),x(Cv+vsegment.num(vsegment.end==204))];
% % inp = segment.distrind{segment.num(segment.end==110)};
% % onp = vsegment.distrind{vsegment.num(vsegment.end==186)};
% c = mean(coS(inp{7},:))';
% c1 = c - min(c);
% cv = mean(coS(onp{5},:))';
% cv1 = cv - min(cv);
% inp = segment.distrind{segment.num(segment.end==6)};
% onp = vsegment.distrind{vsegment.num(vsegment.end==204)};
% c2 = coS(inp{5},:)';
% c2 = c - min(c);
% cv = mean(coS(onp{5},:))';
% cv2 = cv - min(cv);
% 
% cut = lim;
% t = Time(1:cut);
% Ca1 = INT_TRAP(t,c1);
% Cv1 = INT_TRAP(t,cv1);
% Ca2 = INT_TRAP(t,c2);
% Cv2 = INT_TRAP(t,cv2);
% N = roi(1:cut)*sum(Roi(:))*Grid.volume;
% N2 = INT_TRAP(t,c1*Fri(1)+c2*Fri(2)-cv1*Fro(1)-cv2*Fro(2));
% Cr = INT_TRAP(t,N);
% Cr2 = INT_TRAP(t,N2);
% [Cr(end) Cr2(end)]
% (Cr(end)-Cr2(end))/Cr2(end)*100
% figure; plot(t,N,t,N2,'LineWidth',2);
% legend('N_{ROI}(t)','N_{real}')
% xlabel('Time[s]')
% ylabel('Number of moles[mmol]')
% % F = N./(Cai-Cvo);
% figure; plot(t,Ca1,t,Ca2,t,Cv1,t,Cv2,'LineWidth',2);
% legend('Ca_1(t)dt','Ca_2(t)dt','Cv_1(t)dt','Cv_2(t)dt')
% xlabel('Time[s]')
% ylabel('[mmol ml^{-1} s]')

% %% Freehand 2
% Co = node.n + vnode.n;  Cv = Co + segment.n;    Cq = Cv+vsegment.n;
% Roi = logical(freehand2);
% roi = full(mean(coS(Roi,1:lim)))';
% roi = roi - min(roi(:));
% Fri = [x(Co+segment.num(segment.end==5)),x(Co+segment.num(segment.end==6))];
% Fro = [x(Cv+vsegment.num(vsegment.end==3))];
% inp = segment.distrind{segment.num(segment.end==5)};
% onp = vsegment.distrind{vsegment.num(vsegment.end==3)};

% Fri = [x(Co+segment.num(segment.end==103)),x(Co+segment.num(segment.end==110))];
% Fro = [x(Cv+vsegment.num(vsegment.end==186)),x(Cv+vsegment.num(vsegment.end==204))];
% inp = segment.distrind{segment.num(segment.end==110)};
% onp = vsegment.distrind{vsegment.num(vsegment.end==186)};
% c = mean(coS(inp{7},:))';
% c1 = c - min(c);
% cv = mean(coS(onp{5},:))';
% cv1 = cv - min(cv);
% inp = segment.distrind{segment.num(segment.end==6)};
% onp = vsegment.distrind{vsegment.num(vsegment.end==204)};
% c2 = coS(inp{5},:)';
% c2 = c - min(c);
% cv = mean(coS(onp{5},:))';
% cv2 = cv - min(cv);
% 
% cut = lim;
% t = Time(1:cut);
% Ca1 = INT_TRAP(t,c1);
% Cv1 = INT_TRAP(t,cv1);
% Ca2 = INT_TRAP(t,c2);
% Cv2 = INT_TRAP(t,cv2);
% N = roi(1:cut)*sum(Roi(:))*Grid.volume;
% N2 = INT_TRAP(t,c1*Fri(1)+c2*Fri(2)-cv1*Fro(1)-cv2*Fro(2));
% Cr = INT_TRAP(t,N);
% Cr2 = INT_TRAP(t,N2);
% [Cr(end) Cr2(end)]
% (Cr(end)-Cr2(end))/Cr2(end)*100
% figure; plot(t,N,t,N2,'LineWidth',2);
% legend('N_{ROI}(t)','N_{real}')
% xlabel('Time[s]')
% ylabel('Number of moles[mmol]')
% % F = N./(Cai-Cvo);
% figure; plot(t,Ca1,t,Ca2,t,Cv1,t,Cv2,'LineWidth',2);
% legend('Ca_1(t)dt','Ca_2(t)dt','Cv_1(t)dt','Cv_2(t)dt')
% xlabel('Time[s]')
% ylabel('[mmol ml^{-1} s]')

function [Fl,sgde,vgde,cgde,reg] = Floreg(prm,Grid,node,vnode,segment,vsegment,Connect,x,Roi)
Co = node.n + vnode.n; Cv = Co+segment.n; Cq = Cv+vsegment.n;
Skel = zeros(Grid.Nx,Grid.Ny);        
nm = 1;        
for i=1:segment.n
    ns = length(segment.Cnum{i});
    for j = 1:ns
    Skel(segment.ind{i}(j)) = nm;
    end
    nm = nm + 1; 
end
for i=1:vsegment.n
    ns = length(vsegment.Cnum{i});
    for j = 1:ns
    Skel(vsegment.ind{i}(j)) = nm;
    end
    nm = nm + 1; 
end

for i=1:Connect.n
    ns = length(Connect.Cnum{i});
    for j = 1:ns
    Skel(Connect.ind{i}(j)) = nm;
    end
    nm = nm + 1; 
end
for i=1:node.n
    Skel(node.ind{i}) = nm;
    nm = nm + 1; 
end
for i=1:vnode.n
    Skel(vnode.ind{i})= nm;
    nm = nm + 1; 
end

%% Compute the total flow through vessels into the ROI
area = Skel(Roi);
area = unique(nonzeros(area));

sgde = area(area<=segment.n);
vgde = area(area>segment.n & area<=segment.n+vsegment.n) - segment.n;
cgde = area(area>segment.n+vsegment.n & area<=segment.n+vsegment.n+Connect.n) - (segment.n+vsegment.n);
nde = area(area>segment.n+vsegment.n+Connect.n & area<=node.n+segment.n+vsegment.n+Connect.n) - (segment.n+vsegment.n+Connect.n);
vde = area(area>node.n+segment.n+vsegment.n+Connect.n) - (node.n+segment.n+vsegment.n+Connect.n);

% remove unwanted terminal connection
if ~isempty(cgde)
    conA = Connect.AV(cgde,1);
    conV = Connect.AV(cgde,2);
    tmp = cgde;
    for i = 1 : length(cgde)
        idx = ismember(nde,conA(i));
        idy = ismember(vde,conV(i));
%         if any(idx) && x(Cq+cgde(i))<0 || any(idy) && x(Cq+cgde(i))>0
%             cgde;
%         else 
        if any(idx) && any(idy)
            tmp(tmp==cgde(i)) = [];
        elseif any(idx) && x(Cq+cgde(i))>0
            tmp(tmp==cgde(i)) = [];
        elseif any(idy) && x(Cq+cgde(i))<0
            tmp(tmp==cgde(i)) = [];
        end
    end
    cgde = tmp;
end

% remove unwanted vein segment
if ~isempty(nde)
    clog = node.clog(nde);
    clog = nde(clog);
    for i = 1 : length(clog)    % remove clogged vessels
        ab = segment.num(segment.end==clog(i));
        ba = segment.num(segment.init==clog(i));
        idx = ismember(sgde,[ba,ab]);
        sgde(idx)=[];
    end
    junc = node.isterminal(nde);
    nde = nde(~junc);
    for i = 1 : length(nde)     % remove connected and junction vessel
        ba = segment.num(segment.init==nde(i));
        ab = segment.num(segment.end==nde(i));
        % add some missing segments around node
        sgde = unique([sgde;ab';ba']);
    end
    for i = 1 : length(nde)     % remove connected and junction vessel
        ba = segment.num(segment.init==nde(i));
        ab = segment.num(segment.end==nde(i));
        if x(Co+ab)>0   % remove unwanted segment
            ba = ba(x(Co+ba)>0);
            idx = ismember(sgde,ba);
            sgde(idx)=[];
        else
            ba = ba(x(Co+ba)>0);
            idx = ismember(sgde,[ba,ab]);
            sgde(idx)=[];
        end
    end
end

% remove unwanted venous segment
if ~isempty(vde)
    clog = vnode.clog(vde);
    clog = vde(clog);
    for i = 1 : length(clog)    % remove clogged vessel
        ab = segment.num(segment.end==clog(i));
        ba = segment.num(segment.init==clog(i));
        idx = ismember(vgde,[ba,ab]);
        vgde(idx)=[];
    end
    junc = vnode.isterminal(vde);
    tde = vde(~junc);
    for i = 1 : length(tde)     % remove connected and junction vessel
        ba = vsegment.num(vsegment.init==tde(i));
        ab = vsegment.num(vsegment.end==tde(i));
        % add some missing segments around node
        vgde = unique([vgde;ab';ba']);
    end
    for i = 1 : length(tde)     % remove connected and junction vessel
        ba = vsegment.num(vsegment.init==tde(i));
        ab = vsegment.num(vsegment.end==tde(i));
        if x(Cv+ab)<0
            ba = ba(x(Cv+ba)<0);
            idx = ismember(vgde,ba);
            vgde(idx)=[];
        else
            ba = ba(x(Cv+ba)<0);
            idx = ismember(vgde,[ba,ab]);
            vgde(idx)=[];
        end
    end
    junc = vnode.isterminal(vde);
    tde = vde(junc);
    for i = 1 : length(tde)
        ab = vsegment.num(vsegment.end==tde(i));
        if x(Cv+ab)>0
            idx = ismember(vgde,ab);
            vgde(idx)=[];        
        end
    end
end

% Total flow into ROI
% Fl = sum(abs([x(Co+sgde)./(pi*segment.rad(sgde).^2);x(Cv+vgde)./(pi*vsegment.rad(vgde).^2);x(Cq+cgde)./(pi*Connect.rad(cgde).^2)]))*0.55*60/100;
Fl = sum(abs(x([Co+sgde;Cv+vgde;Cq+cgde])))*0.55*60;
% Fl = sum(abs(x([Co+sgde;Cv+vgde;Cq+cgde])))*0.55*60/10/prm.pixel;
end

function trapz_int_final = INT_TRAP(t,c)
    n = length(t);
    dt = t(2:n)-t(1:n-1);
    trapz_int = dt.*(c(1:n-1)+c(2:n))/2;
    trapz_int_2 = [0;trapz_int]; 
    trapz_int_final = cumsum(trapz_int_2);
end

function trapz_int_final = INT_T(t,c)
    n = length(t);
    dt = t(2:n)-t(1:n-1);
    trapz_int = dt.*(c(1:n-1)+c(2:n))/2;
    trapz_int_2 = [0;trapz_int]; 
    trapz_int_final = cumsum(trapz_int_2);
end
