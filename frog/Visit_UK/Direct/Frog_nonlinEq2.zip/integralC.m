% function [N] = integralC(Grid,node,segment,vnode,vsegment,Connect,coSave,x,Time,ROI)
Co = node.n + vnode.n;  Cv = Co + segment.n;    Cq = Cv+vsegment.n; 
% ROI choosen 
ROI = logical(F1);
Roi = logical(ROI);
% bw perimeter outside ROI
Rper = bwmorph(Roi,'thicken',1);
% Skeleton mapping segment
Skel = SkelAll(Grid,node,vnode,segment,vsegment,Connect);
% Concentration array time series
lim = size(coSave,2)-1;
coS = coSave(:,1:lim);
roi = full(mean(coS(Roi,1:lim)));
% Find segment and ROI intersection 
[indA,sA,indV,sV,indC,sC] = intersect(node,vnode,segment,vsegment,Connect,Skel,Rper,x);
sV=242;
Fri = x(Co+sA);
indA = segment.distrind{sA}{1};
% sA(abs(Fri)<1e-10)=[];
Fri(abs(Fri)<1e-10)=[];
Fro = x(Cv+sV);
% indV(abs(Fro)<1e-13)=[];
indV = vsegment.distrind{sV}{1};
sV(abs(Fro)<1e-10)=[];
Fro(abs(Fro)<1e-10)=[];
c = cISave(Co+NCs+segment.Cnum{sA}(end),1:lim); 
% c = c - min(c,1);
cv = cISave(Co+NCs+NAs+vsegment.Cnum{sV}(end),1:lim);
% cv = cv - min(cv,1);
% 
t = Time(1:lim);
Cai = INT_TRAP(t,c);
Cvo = INT_TRAP(t,cv);
Cr = INT_TRAP(t,roi);
N = roi(1:lim)*(sum(Roi(:)))*Grid.volume;
N2 = INT_TRAP(t,Fri'*c-Fro'*cv);
Cr = INT_TRAP(t,N);
Cr2 = INT_TRAP(t,N2);
[Cr(end) Cr2(end)]
(Cr(end)-Cr2(end))/Cr2(end)*100
figure(1); plot(t,N,t,N2,'LineWidth',2);
legend('N_{ROI}(t)','N_{inside}(t)')
xlabel('Time[s]')
ylabel('Number of moles[mmol]')
% 
N3 = INT_TRAP(t,Fri'*Cai-Fro'*Cvo);
F = N3./(Cai-Cvo);
figure(2); plot(t,Fri'*Cai,t,Fro'*Cvo,'LineWidth',2);
legend('Ca(t)dt','Cv(t)dt')
xlabel('Time[s]')
ylabel('[mmol ml^{-1} s]')
% figure(3); plot(t,N3,'LineWidth',2);
% legend('N_{ROI}(t)')
% xlabel('Time[s]')
% ylabel('Mol[mmol]')

    function [indA,sA,indV,sV,indC,sC] = intersect(node,vnode,segment,vsegment,Connect,Skel,Rper,x)
    Co = node.n + vnode.n;  Cv = Co + segment.n;    Cq = Cv+vsegment.n; 
        Roi = Rper;
        Rper = bwperim(Rper);
        indA = find(Rper&segment.skel);
        indV = find(Rper&vsegment.skel);
        indC = find(Rper&logical(Skel)&~segment.skel&~vsegment.skel);
%         temp = Skel(indA);
%         temp = unique(nonzeros(temp));
%         sA = temp(temp<=segment.n);
%         temp = Skel(indV);
%         temp = unique(nonzeros(temp));
%         sV = temp(temp>segment.n & temp<=segment.n+vsegment.n) - segment.n;
%         temp = Skel(indC);
%         temp = unique(nonzeros(temp));
%         sC = temp(temp>segment.n+vsegment.n & temp<=segment.n+vsegment.n+Connect.n) - (segment.n+vsegment.n);
        area = Skel(Roi);
        area = unique(nonzeros(area));

sgde = area(area<=segment.n);
vgde = area(area>segment.n & area<=segment.n+vsegment.n) - segment.n;
cgde = area(area>segment.n+vsegment.n & area<=segment.n+vsegment.n+Connect.n) - (segment.n+vsegment.n);
nde = area(area>segment.n+vsegment.n+Connect.n & area<=node.n+segment.n+vsegment.n+Connect.n) - (segment.n+vsegment.n+Connect.n);
vde = area(area>node.n+segment.n+vsegment.n+Connect.n) - (node.n+segment.n+vsegment.n+Connect.n);

% remove unwanted terminal connection
if ~isempty(cgde)
    conA = Connect.AV(cgde,1);
    conV = Connect.AV(cgde,2);
    tmp = cgde;
    for i = 1 : length(cgde)
        idx = ismember(nde,conA(i));
        idy = ismember(vde,conV(i));
%         if any(idx) && x(Cq+cgde(i))<0 || any(idy) && x(Cq+cgde(i))>0
%             cgde;
%         else 
        if any(idx) && any(idy)
            tmp(tmp==cgde(i)) = [];
        elseif any(idx) && x(Cq+cgde(i))>0
            tmp(tmp==cgde(i)) = [];
        elseif any(idy) && x(Cq+cgde(i))<0
            tmp(tmp==cgde(i)) = [];
        end
    end
    cgde = tmp;
end

% remove unwanted vein segment
if ~isempty(nde)
    clog = node.clog(nde);
    clog = nde(clog);
    for i = 1 : length(clog)    % remove clogged vessels
        ab = segment.num(segment.end==clog(i));
        ba = segment.num(segment.init==clog(i));
        idx = ismember(sgde,[ba,ab]);
        sgde(idx)=[];
    end
    junc = node.isterminal(nde);
    nde = nde(~junc);
    for i = 1 : length(nde)     % remove connected and junction vessel
        ba = segment.num(segment.init==nde(i));
        ab = segment.num(segment.end==nde(i));
        % add some missing segments around node
        sgde = unique([sgde;ab';ba']);
    end
    for i = 1 : length(nde)     % remove connected and junction vessel
        ba = segment.num(segment.init==nde(i));
        ab = segment.num(segment.end==nde(i));
        if x(Co+ab)>0   % remove unwanted segment
            ba = ba(x(Co+ba)>0);
            idx = ismember(sgde,ba);
            sgde(idx)=[];
        else
            ba = ba(x(Co+ba)>0);
            idx = ismember(sgde,[ba,ab]);
            sgde(idx)=[];
        end
    end
end

% remove unwanted venous segment
if ~isempty(vde)
    clog = vnode.clog(vde);
    clog = vde(clog);
    for i = 1 : length(clog)    % remove clogged vessel
        ab = segment.num(segment.end==clog(i));
        ba = segment.num(segment.init==clog(i));
        idx = ismember(vgde,[ba,ab]);
        vgde(idx)=[];
    end
    junc = vnode.isterminal(vde);
    tde = vde(~junc);
    for i = 1 : length(tde)     % remove connected and junction vessel
        ba = vsegment.num(vsegment.init==tde(i));
        ab = vsegment.num(vsegment.end==tde(i));
        % add some missing segments around node
        vgde = unique([vgde;ab';ba']);
    end
    for i = 1 : length(tde)     % remove connected and junction vessel
        ba = vsegment.num(vsegment.init==tde(i));
        ab = vsegment.num(vsegment.end==tde(i));
        if x(Cv+ab)<0 % flow from parent to child
            ba = ba(x(Cv+ba)<0);
            idx = ismember(vgde,ba);
            vgde(idx)=[];
        else 
            ba = ba(x(Cv+ba)<0);
            idx = ismember(vgde,[ba,ab]);
            vgde(idx)=[];
        end
    end
    junc = vnode.isterminal(vde);
    tde = vde(junc);
    for i = 1 : length(tde)
        ab = vsegment.num(vsegment.end==tde(i));
        if x(Cv+ab)>0
            idx = ismember(vgde,ab);
            vgde(idx)=[];        
        end
    end
end
sA = sgde;  sV = vgde;  sC = cgde;
    end
    function [Skel] = SkelAll(Grid,node,vnode,segment,vsegment,Connect)
Co = node.n + vnode.n; Cv = Co+segment.n; Cq = Cv+vsegment.n;
Skel = zeros(Grid.Nx,Grid.Ny);        
nm = 1;        
for i=1:segment.n
    ns = length(segment.Cnum{i});
    for j = 1:ns
    Skel(segment.ind{i}(j)) = nm;
    end
    nm = nm + 1; 
end
for i=1:vsegment.n
    ns = length(vsegment.Cnum{i});
    for j = 1:ns
    Skel(vsegment.ind{i}(j)) = nm;
    end
    nm = nm + 1; 
end

for i=1:Connect.n
    ns = length(Connect.Cnum{i});
    for j = 1:ns
    Skel(Connect.ind{i}(j)) = nm;
    end
    nm = nm + 1; 
end
for i=1:node.n
    Skel(node.ind{i}) = nm;
    nm = nm + 1; 
end
for i=1:vnode.n
    Skel(vnode.ind{i})= nm;
    nm = nm + 1; 
end
end

    function [Fl,sgde,vgde,cgde,reg] = Floreg(Skel,node,vnode,segment,vsegment,Connect,x,Roi)
Co = node.n + vnode.n; Cv = Co+segment.n; Cq = Cv+vsegment.n;
%% Compute the total flow through vessels into the ROI
area = Skel(Roi);
area = unique(nonzeros(area));

sgde = area(area<=segment.n);
vgde = area(area>segment.n & area<=segment.n+vsegment.n) - segment.n;
cgde = area(area>segment.n+vsegment.n & area<=segment.n+vsegment.n+Connect.n) - (segment.n+vsegment.n);
nde = area(area>segment.n+vsegment.n+Connect.n & area<=node.n+segment.n+vsegment.n+Connect.n) - (segment.n+vsegment.n+Connect.n);
vde = area(area>node.n+segment.n+vsegment.n+Connect.n) - (node.n+segment.n+vsegment.n+Connect.n);

% remove unwanted terminal connection
if ~isempty(cgde)
    conA = Connect.AV(cgde,1);
    conV = Connect.AV(cgde,2);
    tmp = cgde;
    for i = 1 : length(cgde)
        idx = ismember(nde,conA(i));
        idy = ismember(vde,conV(i));
%         if any(idx) && x(Cq+cgde(i))<0 || any(idy) && x(Cq+cgde(i))>0
%             cgde;
%         else 
        if any(idx) && any(idy)
            tmp(tmp==cgde(i)) = [];
        elseif any(idx) && x(Cq+cgde(i))>0
            tmp(tmp==cgde(i)) = [];
        elseif any(idy) && x(Cq+cgde(i))<0
            tmp(tmp==cgde(i)) = [];
        end
    end
    cgde = tmp;
end

% remove unwanted vein segment
if ~isempty(nde)
    clog = node.clog(nde);
    clog = nde(clog);
    for i = 1 : length(clog)    % remove clogged vessels
        ab = segment.num(segment.end==clog(i));
        ba = segment.num(segment.init==clog(i));
        idx = ismember(sgde,[ba,ab]);
        sgde(idx)=[];
    end
    junc = node.isterminal(nde);
    nde = nde(~junc);
    for i = 1 : length(nde)     % remove connected and junction vessel
        ba = segment.num(segment.init==nde(i));
        ab = segment.num(segment.end==nde(i));
        % add some missing segments around node
        sgde = unique([sgde;ab';ba']);
    end
    for i = 1 : length(nde)     % remove connected and junction vessel
        ba = segment.num(segment.init==nde(i));
        ab = segment.num(segment.end==nde(i));
        if x(Co+ab)>0   % remove unwanted segment
            ba = ba(x(Co+ba)>0);
            idx = ismember(sgde,ba);
            sgde(idx)=[];
        else
            ba = ba(x(Co+ba)>0);
            idx = ismember(sgde,[ba,ab]);
            sgde(idx)=[];
        end
    end
end

% remove unwanted venous segment
if ~isempty(vde)
    clog = vnode.clog(vde);
    clog = vde(clog);
    for i = 1 : length(clog)    % remove clogged vessel
        ab = segment.num(segment.end==clog(i));
        ba = segment.num(segment.init==clog(i));
        idx = ismember(vgde,[ba,ab]);
        vgde(idx)=[];
    end
    junc = vnode.isterminal(vde);
    tde = vde(~junc);
    for i = 1 : length(tde)     % remove connected and junction vessel
        ba = vsegment.num(vsegment.init==tde(i));
        ab = vsegment.num(vsegment.end==tde(i));
        % add some missing segments around node
        vgde = unique([vgde;ab';ba']);
    end
    for i = 1 : length(tde)     % remove connected and junction vessel
        ba = vsegment.num(vsegment.init==tde(i));
        ab = vsegment.num(vsegment.end==tde(i));
        if x(Cv+ab)<0
            ba = ba(x(Cv+ba)<0);
            idx = ismember(vgde,ba);
            vgde(idx)=[];
        else
            ba = ba(x(Cv+ba)<0);
            idx = ismember(vgde,[ba,ab]);
            vgde(idx)=[];
        end
    end
    junc = vnode.isterminal(vde);
    tde = vde(junc);
    for i = 1 : length(tde)
        ab = vsegment.num(vsegment.end==tde(i));
        if x(Cv+ab)>0
            idx = ismember(vgde,ab);
            vgde(idx)=[];        
        end
    end
end

% Total flow into ROI
% Fl = sum(abs([x(Co+sgde)./(pi*segment.rad(sgde).^2);x(Cv+vgde)./(pi*vsegment.rad(vgde).^2);x(Cq+cgde)./(pi*Connect.rad(cgde).^2)]))*0.55*60/100;
Fl = sum(abs(x([Co+sgde;Cv+vgde;Cq+cgde])))*0.55*60;
% Fl = sum(abs(x([Co+sgde;Cv+vgde;Cq+cgde])))*0.55*60/10/prm.pixel;
end

function trapz_int_final = INT_TRAP(t,c)
    n = length(t);
    nC = size(c,1);
    dt = repmat(t(2:n)-t(1:n-1),1,nC)';
    trapz_int = dt.*(c(:,1:n-1)+c(:,2:n))/2;
    trapz_int_2 = [zeros(nC,1),trapz_int]; 
    trapz_int_final = cumsum(trapz_int_2);
end

function trapz_int_final = INT_T(t,c)
    n = length(t);
    dt = t(2:n)-t(1:n-1);
    trapz_int = dt.*(c(1:n-1,:)+c(2:n,:))/2;
    trapz_int_2 = [zeros();trapz_int]; 
    trapz_int_final = cumsum(trapz_int_2);
end
% end