%% Fitting 2CM uptake
P = [0.3, 125.0/6000, 2.0/3, 12/120.]; % #[VP+VE, FP, VE/(VP+VE), PS/FP] Tissue parameters for initilizing model fitting
Hct = 0.45; % #Haematocrit factor
bL = 9; % # Baseline, default=9
r = 3.6; % # Relaxivity in Hz/mM, used in function Concentration_SPGRESS
s = [-10,10,0.5]; % # Delay values: minimum, maximum and step size, used in function add_delay

delay_condition = True; % # # When true adds arterial delay to the linear model 
T1_condition = False; %#True  #  # When true measured T1-values are used in the nonlinear model

## Loop over study groups ##
for d1 in study:
    P_fit =[]; %
    params =[]; %
    study_id =[]; %
    kidney = []; %
    name=[]; %
    
    ## Parameter values for 'Nonlinear' model, used in function Concentration_SPGRESS  ####
    if d1=='1Tdata':
        FA = 20.00 #Flip angle in degrees
        TR = 5.40 #Repetition time in msec
        R10_kid = 1/906 # Precontrast relaxation rate in kidney (de Bazelaire JMRI 2004)
        R10_aif = 1/1574.42# Precontrast relaxation rate in artery (Reference in Lu MRM 2004)
    else:    
        FA = 17.00
        TR = 5.05 
        R10_kid =  1/1142   # Precontrast relaxation rate in kidney (de Bazelaire JMRI 2004)
        R10_aif = (0.52 * Hct + 0.38)/1000 # Precontrast relaxation rate in artery (Lu MRM 2004)
        T10_aif = 1/R10_aif   
    
           
                Time0 = t1.split()
                Time = np.asarray(Time0,dtype=np.float64)
                r0 = r1.split()
                roi = np.asarray(r0,dtype=np.float64)
                
                roi0 = np.mean(roi[0:bL])
                aif0 =  np.mean(aif[0:bL])
                roi_new = roi-roi0  # Signal for kidney after baseline correction
                aif_new = (aif-aif0)/(1-Hct) # AIF after baseline and haematocrit correction
                
%                 ## Fitting concentration with chosen model ##
                if model == 'Linear':
                    if n=='AC 51a' and kidney_id[ii]== 'RK': # 2Cuptake model is used for one patient 
                        fit_model = 'uptake'
                        if delay_condition == True:
                            res, fit = add_delay(P,Time, aif_new,roi_new,s,n,fit_model)      
                        else:
                            res = least_squares(fun_uptake, P, method='lm',  args=(Time, roi_new,aif_new), max_nfev=20000, verbose=1)       
                            fit = model_uptake(res.x,Time, aif_new)
                    else:  
                        fit_model = '2CFM'
                        if delay_condition == True:
                            res, fit = add_delay(P,Time, aif_new,roi_new,s,n,fit_model) 
                        else:
                            res = least_squares(fun_2CFM, P, method='lm',  args=(Time, roi_new,aif_new), max_nfev=20000, verbose=1)       
                            fit = model_2CFM(res.x,Time, aif_new)                            
                            
                elif model == 'Nonlinear':
                    aif_nonlinear = Concentration_SPGRESS(aif, aif0, T10_aif, FA, TR, r)/(1-Hct)
                    roi_nonlinear = Concentration_SPGRESS(roi, roi0, T10_kid[ii], FA, TR, r)
                    if n=='AC 51a' and kidney_id[ii]== 'RK': # 2Cuptake model is used for one patient
                        res = least_squares(fun_uptake, P, method='lm',  args=(Time, roi_nonlinear,aif_nonlinear), max_nfev=20000,verbose=1) 
                        fit = model_uptake(res.x,Time, aif_nonlinear)
                    else:
                        res = least_squares(fun_2CFM, P, method='lm',  args=(Time, roi_nonlinear,aif_nonlinear),max_nfev=20000, verbose=1) 
                        fit = model_2CFM(res.x,Time, aif_nonlinear)
                                       
%                 ## Calculate parameters from fitting ##
                BF = 6000*res.x[1]/(1 -Hct)	#Blood Flow
                BMTT = 1*res.x[0]*(1-res.x[2])/res.x[1] #Blood MTT
                BV = 100*res.x[0]*(1-res.x[2])/(1 -Hct) #Blood Volume
                TMTT = 1*res.x[0]*res.x[2]/(res.x[1]*res.x[3])/60 #Tubular MTT
                EF = 100*res.x[3] #Extraction Fraction
                TF = 6000*res.x[1]*res.x[3]	#Tubular Flow
                GFR = Vol_kid[ii]*60*res.x[1]*res.x[3] 
                fVol = Vol_kid[ii] # Region Volume
                chiSq = 100*np.sum((fit -roi_new)**2)/np.sum(roi_new**2)
                isoGFR = isoGFR_kid[ii]
                
                P_fit.append([BF,BMTT,BV,TMTT,EF,TF,isoGFR,GFR,fVol,chiSq])
                params.append(["BF","BMTT","BV","TMTT","E","TF","Iso-SK-GFR","SK-GFR","fVol","Chi-square"])
                kidney.append(np.repeat('%s' %kidney_id[ii],10))
                study_id.append(np.repeat('%s' %n,10))              
   
#                plt.figure()
#                plt.plot(Time,roi_new,'o')#,markerfacecolor='None')
#                plt.plot(Time,fit,'r')
                #plt.text(150, 0.01,'Linear_%s %s' % (n,kidney_id))
                       
    os.chdir('..')                        
       
    P_fit = np.ravel(P_fit)
    params = np.ravel(params)
    study_id = np.ravel(study_id)        
    kidney = np.ravel(kidney)   
    access = np.ones(len(P_fit))
    accessSF = np.ones(len(P_fit))
    accessSF[np.where((study_id == 'MRH008-15'))[0]] = 0.0 #Patient with one kidney, not included in SRF calculation
    accessSF[np.where((study_id == 'Ha21'))[0]] = 0.0  #Patient with one kidney, not included in SRF calculation
    accessSF[np.where((study_id == 'Ra40'))[0]] = 0.0  #Patient with one kidney, not included in SRF calculation
    ab = np.column_stack((study_id,kidney,params,P_fit,access,accessSF))
    
    if delay_condition == True:
        header = np.array(['Patient', 'Kidney', 'Parameter','Value_Delay' ,'Access','AccessSF'])
    elif T1_condition == True:
        header = np.array(['Patient', 'Kidney', 'Parameter','Value_NLT1' ,'Access','AccessSF'])    
    else:
        header = np.array(['Patient', 'Kidney', 'Parameter','Value_%s' %model,'Access','AccessSF'])
    ab1 = np.vstack((header,ab))
     
   
    ## Save parameters (one file per study group) ## 
    if delay_condition == True:
        np.savetxt('%s_Delay.csv' %(d1), ab1, fmt="%s",delimiter = ",")
    elif T1_condition == True:    
        np.savetxt('%s_NLT1.csv' %(d1), ab1, fmt="%s",delimiter = ",")
    else:    
        np.savetxt('%s_%s.csv' %(d1,model), ab1, fmt="%s",delimiter = ",")
   
   
        
        
