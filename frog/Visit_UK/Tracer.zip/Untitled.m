tic;
Tt = 100;
dt = 0.0001;
TL = 0 : dt : Tt;
Tc = numel(TL);
c = zeros(Co+Grid.N+NAs+NVs,1);
% cASave = sparse(Grid.N,round(Tc/dV));
% cVSave = sparse(Grid.N,round(Tc/dV));
% cCSave = sparse(Grid.N,round(Tc/dV));
% cCombSave = sparse(Grid.N,round(Tc/dV));
% cSave = sparse(round(Grid.Nx/dn)*round(Grid.Ny/dn),round(Tc/dV));
% Initial concentration in arterial root
C0 = 1;
t0 = 0;
%fixed parameters
a  = 1.5;   b  = 10;
%change from minutes to seconds
t  = TL*60; t0 = t0*60; dt=dt*60;
dV = 10*round(0.05/dt); % video data iteration interval
dn = 30;    % Coarsening factor
%get the AIF
AIF = C0*(t-t0).^a.*exp(-(t-t0)./b);
AIF = AIF.*(t>=t0);
c(1:2,1) = AIF(1);
%% Combine block matrices
A = speye(Co+Grid.N+NAs+NVs) + dt*[AT,ACT,sparse(node.n,vnode.n),ATS,sparse(node.n,NVs);...
    ATC,AC,VTC,sparse(N,NAs+NVs);...
    zeros(vnode.n,node.n),VCT,VT,sparse(vnode.n,NAs),VTS;...
    AST,sparse(NAs,N+vnode.n),AS,sparse(NAs,NVs);...
    sparse(NVs,N+node.n),VST,sparse(NVs,NAs),VS];
% Color scale
clim = [0,0.15*max(AIF)];
% Open movie
folder = ['Result/',date,'/'];
[~,~,~] = mkdir(folder);
% subfolder = [folder,'/A';folder,'/V';folder,'/C';folder,'/I';folder,'/L'];
% for i =1:5
%     [~,~,~] = mkdir(subfolder(i,:));
% end
pathsave = [folder,'Coarse.avi'];
msg = ['Saving ' pathsave];
disp(msg);
v = VideoWriter(pathsave);
v.FrameRate = 100;
open(v);
H = figure('Position',[300,200,700,400]);
% iteration
lm = 1;  % Counter to save the data
csum = c;
% write Dicom info
cS=reshape(c(1:Grid.N),Grid.Nx,Grid.Ny);
dicomwrite(cS,[folder '/im_trial.dcm']);
info = dicominfo([folder '/im_trial.dcm']);
for iter = 2 : Tc
c = max(A*c,0);
c(1:2) = AIF(iter);
csum = csum+c;
if iter>numel(TL)/3
    dV = 4*dV;
end
if mod(iter,dV)==0
    cInt = csum/dV;
    cA = sparse(Grid.Nx,Grid.Ny); cV = sparse(Grid.Nx,Grid.Ny);
for i=1:segment.n
    ns = length(segment.Cnum{i});
    for j = 1:ns
    cA(segment.distrind{i}{j})=cInt(Co+Grid.N+segment.Cnum{i}(j));
    end
end
for i=1:vsegment.n
    ns = length(vsegment.Cnum{i});
    for j = 1:ns
    cV(vsegment.distrind{i}{j})=cInt(Co+Grid.N+NAs+vsegment.Cnum{i}(j));
    end
end
for i=1:node.n
    cA(node.ind{i})=cInt(i);
end
for i=1:vnode.n
    cV(vnode.ind{i})=cInt(node.n+Grid.N+i);
end
cC = sparse(reshape(cInt(node.n+1:node.n+Grid.N),Grid.Nx,Grid.Ny))*prm.Por;
I = Grid.B*0.5+cA+cV+cC;
Lores = imresize(I,1/dn); 
% figure(1); clf;
% imagesc(Lores,clim);axis image;axis off; title('Coarse');daspect([1 1 1])
figure(H);
subplot(2,2,1);imagesc(cA,clim);axis image;axis off;title('Arterial tree');
subplot(2,2,2);imagesc(cV,clim);axis image;axis off;title('Venous tree');
subplot(2,2,3);imagesc(Lores,clim);axis image;axis off;title('Capillary');
subplot(2,2,4);imagesc(I,clim);colormap(bone);axis image;axis off;title('Combined');
frame = getframe(gcf);
writeVideo(v,frame);
% writeDicom(cA,lm,Grid,t,iter,subfolder(1,:));
% writeDicom(cV,lm,Grid,t,iter,subfolder(2,:));
% writeDicom(cC,lm,Grid,t,iter,subfolder(3,:));
% writeDicom(I,lm,Grid,t,iter,subfolder(4,:));
% writeDicom(Lores,lm,Grid,t,iter,subfolder(5,:));
% cSave(:,lm)=Lores(:);
% cASave(:,lm)=cA(:);
% cVSave(:,lm)=cV(:);
cCSave(:,lm)=cC(:);
cCombSave(:,lm)=I(:);
lm=lm+1
end
end
close(v);
function writeDicom(C,lm,Grid,t,k,name)
info.AcquisitionTime = t(k);
cS=reshape(C,Grid.Nx,Grid.Ny);
dicomwrite(cS,[name '/im',sprintf('%04d', lm),'.dcm'],info);
end

function Lores = Rescal(I,dn)
 NS=size(I);
 for k=1:round(NS(1)/dn)
     if k==round(NS(1)/dn)
             for l=1:round(NS(2)/dn)
        if l==round(NS(2)/dn)
            kn = dn*(k-1)+1;
            ln = dn*(l-1)+1;
            Sample=I(kn:end,ln:end);
            Lores(k,l)=mean(Sample(:)); 
        else
        kn = dn*(k-1)+1;
        ln = dn*(l-1)+1;
        Sample=I(kn:end,ln:ln+dn-1);
        Lores(k,l)=mean(Sample(:));
        end
             end
     else
     for l=1:round(NS(2)/dn)
        if l==round(NS(2)/dn)
            kn = dn*(k-1)+1;
            ln = dn*(l-1)+1;
            Sample=I(kn:kn+dn-1,ln:end);
            Lores(k,l)=mean(Sample(:)); 
        else
        kn = dn*(k-1)+1;
        ln = dn*(l-1)+1;
        Sample=I(kn:kn+dn-1,ln:ln+dn-1);
        Lores(k,l)=mean(Sample(:));
        end
     end
     end
 end
end