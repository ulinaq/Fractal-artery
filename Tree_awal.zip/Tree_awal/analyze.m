function analyze(prm,P,V,Grid,GA,GV,node,vnode,name)
Pan = reshape(P(1:Grid.N),Grid.Nx,Grid.Ny);
Pvn = reshape(P(Grid.N+1:2*Grid.N),Grid.Nx,Grid.Ny);

filename{1} = ['Fig/PA',name];
filename{2} = ['Fig/PV',name];
filename{3} = ['Fig/ToFA',name];
filename{4} = ['Fig/ToFV',name];

figure(1)
clf;
imagesc([1 515]*prm.pixel,[1 634]*prm.pixel,Pan,'AlphaData',Grid.B); axis ij; title('Pressure in artery compartment'); daspect([1 1 1])
caxis([min(P) max(P)]); set(gca,'color','w');
% contourf(P); colormap(gray); colorbar; title('Pressure');
hcb=colorbar;
title(hcb,'P [kPa]')
xlabel('x [mm]')
ylabel('y [mm]')
hold on
% plot(GV,'b','YData',vnode.XData,'XData',vnode.YData,'LineWidth',GV.Edges.width,'DisplayName','Venal tree structure');
% daspect([1 1 1])
plot(GA,'r','YData',node.XData,'XData',node.YData,'LineWidth',GA.Edges.width,'DisplayName','Arterial tree structure');
daspect([1 1 1])
set(gcf, 'Color', 'w'); 
export_fig(filename{1},'-r300'); 


figure(2)
clf;
imagesc([1 515]*prm.pixel,[1 634]*prm.pixel,Pvn,'AlphaData',Grid.B);  title('Pressure in vein compartment');daspect([1 1 1])
caxis([min(P) max(P)]); %set(gca,'color',0*[1 1 1]);
% contourf(P); colormap(gray); colorbar; title('Pressure');
hcb=colorbar;
title(hcb,'P [kPa]')
xlabel('x [mm]')
ylabel('y [mm]')
hold on
plot(GV,'b','YData',vnode.XData,'XData',vnode.YData,'LineWidth',GV.Edges.width,'DisplayName','Venal tree structure');
daspect([1 1 1])
% plot(GA,'r','YData',node.XData,'XData',node.YData,'LineWidth',GA.Edges.width,'DisplayName','Arterial tree structure');
% daspect([1 1 1])
set(gcf, 'Color', 'w'); 
export_fig(filename{2},'-r300'); 

figure(3)
clf;
imagesc([1 515]*prm.pixel,[1 634]*prm.pixel,V.Ta,'AlphaData',Grid.B); title('Time of flight in artery compartment');
daspect([1 1 1]); caxis([0 max(V.Ta(Grid.B))*0.7]); %set(gca,'color',0*[1 1 1]);
hold on
hcb=colorbar
title(hcb,'T [s]')
xlabel('x [mm]')
ylabel('y [mm]')
plot(GA,'r','YData',node.XData,'XData',node.YData,'LineWidth',GA.Edges.width,'DisplayName','Arterial tree structure');
daspect([1 1 1])
set(gcf, 'Color', 'w'); 
export_fig(filename{3},'-r300'); 

figure(4)
clf;
imagesc([1 515]*prm.pixel,[1 634]*prm.pixel,V.Tv,'AlphaData',Grid.B); title('Time of flight in vein compartment');
daspect([1 1 1]); caxis([0 max(V.Ta(Grid.B))*0.7]); %set(gca,'color',0*[1 1 1]);
hold on
hcb=colorbar
title(hcb,'T [s]')
xlabel('x [mm]')
ylabel('y [mm]')
plot(GV,'b','YData',vnode.XData,'XData',vnode.YData,'LineWidth',GV.Edges.width,'DisplayName','Venal tree structure');
daspect([1 1 1])
set(gcf, 'Color', 'w'); 
export_fig(filename{4},'-r300'); 
end